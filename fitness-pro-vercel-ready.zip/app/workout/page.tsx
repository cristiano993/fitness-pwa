"use client";

import { useMemo, useState } from "react";
import { ArrowLeft, CheckCircle2, Clock3, Dumbbell, Flame, RotateCcw, Trophy } from "lucide-react";
import { useFitnessData } from "@/hooks/useFitnessData";
import { localDateKey } from "@/lib/store";
import { calculateEstimatedMax } from "@/lib/calculations";

const DAY_LABELS = ["Dom", "Lun", "Mar", "Mer", "Gio", "Ven", "Sab"];

export default function WorkoutPage() {
  const { data, loaded, save } = useFitnessData();
  const [selectedDay, setSelectedDay] = useState(new Date().getDay());
  const [activeWorkoutId, setActiveWorkoutId] = useState<string | null>(null);
  const [sets, setSets] = useState<Record<string, { weight: string; reps: string; completed: boolean }[]>>({});
  const [startedAt, setStartedAt] = useState<number | null>(null);
  const [message, setMessage] = useState("");

  const workout = data.plan?.workouts.find((item) => item.dayOfWeek === selectedDay);
  const activeWorkout = data.plan?.workouts.find((item) => item.id === activeWorkoutId);
  const completedThisWeek = data.workoutLogs.filter((log) => log.date.slice(0, 10) >= localDateKey(new Date(Date.now() - 6 * 86400000))).length;

  const getSets = (exerciseId: string, count: number, weight: number, reps: string) => {
    return sets[exerciseId] ?? Array.from({ length: count }, () => ({ weight: weight > 0 ? String(weight) : "", reps: reps.split("-")[0] || "8", completed: false }));
  };

  const toggleSet = (exerciseId: string, setIndex: number, count: number, weight: number, reps: string) => {
    setSets((current) => {
      const next = [...getSets(exerciseId, count, weight, reps)];
      next[setIndex] = { ...next[setIndex], completed: !next[setIndex].completed };
      return { ...current, [exerciseId]: next };
    });
  };

  const updateSet = (exerciseId: string, setIndex: number, field: "weight" | "reps", value: string, count: number, weight: number, reps: string) => {
    setSets((current) => {
      const next = [...getSets(exerciseId, count, weight, reps)];
      next[setIndex] = { ...next[setIndex], [field]: value };
      return { ...current, [exerciseId]: next };
    });
  };

  const startWorkout = () => {
    if (!workout) return;
    setActiveWorkoutId(workout.id);
    setStartedAt(Date.now());
    setMessage("");
  };

  const completeWorkout = () => {
    if (!activeWorkout) return;
    const duration = startedAt ? Math.max(1, Math.round((Date.now() - startedAt) / 60000)) : activeWorkout.durationMinutes;
    const sessionExercises = activeWorkout.exercises.map((exercise) => ({
      exerciseId: exercise.id,
      completedSets: getSets(exercise.id, exercise.sets, exercise.weight, exercise.reps).map((set) => ({ weight: Number(set.weight) || 0, reps: Number(set.reps) || 0, completed: set.completed })),
    }));
    const totalVolume = sessionExercises.reduce((sum, item) => sum + item.completedSets.reduce((inner, set) => inner + (set.completed ? set.weight * set.reps : 0), 0), 0);
    save((current) => ({
      ...current,
      workoutLogs: [...current.workoutLogs, { id: `session-${Date.now()}`, workoutId: activeWorkout.id, date: new Date().toISOString(), duration, totalVolume, exercises: sessionExercises }],
    }));
    setActiveWorkoutId(null);
    setStartedAt(null);
    setMessage("Allenamento registrato. Ottimo lavoro!");
  };

  const selectedDone = useMemo(() => {
    if (!activeWorkout) return 0;
    return activeWorkout.exercises.reduce((sum, exercise) => sum + getSets(exercise.id, exercise.sets, exercise.weight, exercise.reps).filter((set) => set.completed).length, 0);
  }, [activeWorkout, sets]);

  if (!loaded) return <div className="grid min-h-screen place-items-center text-sm text-slate-500">Caricamento…</div>;

  if (!data.plan) return <div className="mx-auto max-w-3xl px-4 pt-8"><div className="rounded-3xl bg-white p-6 text-center shadow-sm ring-1 ring-slate-200"><Dumbbell className="mx-auto text-blue-600" size={36} /><h1 className="mt-4 text-2xl font-black">Nessun piano attivo</h1><p className="mt-2 text-sm leading-6 text-slate-500">Configura il profilo e genera una settimana per iniziare a registrare i workout.</p><a href="/profile" className="mt-5 inline-flex rounded-xl bg-blue-600 px-4 py-3 text-sm font-bold text-white">Vai al profilo</a></div></div>;

  if (activeWorkout) return (
    <div className="mx-auto max-w-3xl px-4 pt-5 sm:px-6">
      <button type="button" onClick={() => setActiveWorkoutId(null)} className="mb-4 inline-flex items-center gap-2 text-sm font-bold text-slate-500"><ArrowLeft size={16} /> Settimana</button>
      <div className="mb-5 rounded-3xl bg-slate-950 p-5 text-white shadow-xl"><p className="text-xs font-bold uppercase tracking-[0.16em] text-slate-400">Sessione attiva</p><h1 className="mt-1 text-2xl font-black">{activeWorkout.name}</h1><div className="mt-4 flex gap-3 text-xs text-slate-300"><span className="inline-flex items-center gap-1"><Clock3 size={14} /> {activeWorkout.durationMinutes} min</span><span className="inline-flex items-center gap-1"><Flame size={14} /> {selectedDone} serie completate</span></div></div>
      <div className="space-y-3">
        {activeWorkout.exercises.map((exercise) => {
          const rows = getSets(exercise.id, exercise.sets, exercise.weight, exercise.reps);
          const est = exercise.weight > 0 ? calculateEstimatedMax(exercise.weight, Number.parseInt(exercise.reps, 10) || 10) : 0;
          return <section key={exercise.id} className="rounded-3xl bg-white p-4 shadow-sm ring-1 ring-slate-200"><div className="flex items-start justify-between gap-3"><div><h2 className="font-black">{exercise.name}</h2><p className="mt-1 text-xs text-slate-500">{exercise.sets} serie · {exercise.reps} reps · recupero {exercise.restSeconds}s</p></div>{est > 0 && <span className="inline-flex items-center gap-1 rounded-full bg-orange-50 px-2 py-1 text-[11px] font-bold text-orange-700"><Trophy size={12} />1RM ~ {est} kg</span>}</div><div className="mt-3 grid grid-cols-[38px_1fr_1fr_42px] gap-2 text-center text-[10px] font-bold uppercase text-slate-400"><span>#</span><span>kg</span><span>reps</span><span>ok</span></div>{rows.map((set, setIndex) => <div key={`${exercise.id}-${setIndex}`} className={`mt-2 grid grid-cols-[38px_1fr_1fr_42px] items-center gap-2 rounded-xl p-2 ${set.completed ? "bg-emerald-50" : "bg-slate-50"}`}><span className="text-center text-sm font-black">{setIndex + 1}</span><input inputMode="decimal" type="number" value={set.weight} onChange={(e) => updateSet(exercise.id, setIndex, "weight", e.target.value, exercise.sets, exercise.weight, exercise.reps)} className="w-full rounded-lg border border-slate-200 bg-white px-2 py-2 text-center text-sm font-bold" /><input inputMode="numeric" type="number" value={set.reps} onChange={(e) => updateSet(exercise.id, setIndex, "reps", e.target.value, exercise.sets, exercise.weight, exercise.reps)} className="w-full rounded-lg border border-slate-200 bg-white px-2 py-2 text-center text-sm font-bold" /><button type="button" aria-label={`Completa serie ${setIndex + 1}`} onClick={() => toggleSet(exercise.id, setIndex, exercise.sets, exercise.weight, exercise.reps)} className={`grid h-9 w-9 place-items-center rounded-lg ${set.completed ? "bg-emerald-500 text-white" : "bg-white text-slate-300 ring-1 ring-slate-200"}`}><CheckCircle2 size={19} /></button></div>)}{exercise.notes && <p className="mt-3 rounded-xl bg-blue-50 p-3 text-xs leading-5 text-blue-800">{exercise.notes}</p>}</section>;
        })}
      </div>
      <button type="button" onClick={completeWorkout} className="my-5 flex w-full items-center justify-center gap-2 rounded-2xl bg-blue-600 px-4 py-4 text-base font-black text-white shadow-lg"><CheckCircle2 size={21} /> Completa allenamento</button>
    </div>
  );

  return (
    <div className="mx-auto max-w-3xl px-4 pt-5 sm:px-6">
      <header className="mb-5 flex items-end justify-between"><div><p className="text-sm font-medium text-slate-500">Piano settimanale</p><h1 className="text-3xl font-black tracking-tight">Workout</h1></div><span className="rounded-full bg-blue-50 px-3 py-2 text-xs font-bold text-blue-700">{completedThisWeek}/{data.profile.trainingDays} fatti</span></header>
      {message && <div className="mb-4 rounded-2xl bg-emerald-50 p-4 text-sm font-bold text-emerald-800">{message}</div>}
      <div className="mb-5 grid grid-cols-7 gap-1 rounded-2xl bg-white p-2 shadow-sm ring-1 ring-slate-200">{DAY_LABELS.map((label, day) => { const hasWorkout = Boolean(data.plan?.workouts.some((item) => item.dayOfWeek === day)); return <button type="button" key={day} onClick={() => setSelectedDay(day)} className={`rounded-xl py-3 text-center ${selectedDay === day ? "bg-slate-950 text-white" : "text-slate-500"}`}><span className="block text-[10px] font-bold">{label}</span><span className={`mx-auto mt-2 block h-1.5 w-1.5 rounded-full ${hasWorkout ? "bg-blue-500" : "bg-slate-200"}`} /></button>; })}</div>
      {workout ? <section className="rounded-3xl bg-white p-5 shadow-sm ring-1 ring-slate-200"><div className="flex items-start justify-between gap-3"><div><span className="inline-flex rounded-full bg-blue-50 px-2.5 py-1 text-[11px] font-bold text-blue-700">{workout.focus}</span><h2 className="mt-2 text-2xl font-black">{workout.name}</h2><p className="mt-2 text-sm text-slate-500">{workout.exercises.length} esercizi · circa {workout.durationMinutes} minuti</p></div><Dumbbell className="text-blue-600" /></div><div className="mt-5 space-y-2">{workout.exercises.map((exercise) => <div key={exercise.id} className="flex items-center justify-between rounded-2xl bg-slate-50 p-3"><div><p className="text-sm font-bold">{exercise.name}</p><p className="mt-1 text-xs text-slate-500">{exercise.sets} × {exercise.reps} · {exercise.restSeconds}s</p></div><span className="text-xs font-bold text-slate-400">RPE {exercise.rpe ?? 8}</span></div>)}</div><button type="button" onClick={startWorkout} className="mt-5 flex w-full items-center justify-center gap-2 rounded-2xl bg-blue-600 px-4 py-4 text-base font-black text-white shadow-lg">Inizia sessione <Dumbbell size={19} /></button></section> : <section className="rounded-3xl bg-white p-8 text-center shadow-sm ring-1 ring-slate-200"><RotateCcw className="mx-auto text-slate-300" /><h2 className="mt-3 font-black">Giorno di recupero</h2><p className="mt-1 text-sm text-slate-500">Nessun allenamento programmato per oggi.</p></section>}
      <p className="mt-5 pb-4 text-center text-xs leading-5 text-slate-400">Usa carichi gestibili e interrompi l'esercizio in caso di dolore insolito.</p>
    </div>
  );
}
