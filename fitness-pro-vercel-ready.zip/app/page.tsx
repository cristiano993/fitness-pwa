"use client";

import Link from "next/link";
import { ArrowRight, Bot, CalendarDays, CheckCircle2, ChevronRight, Flame, Sparkles, Target, Trophy, Utensils, Zap } from "lucide-react";
import { useFitnessData } from "@/hooks/useFitnessData";
import { getDailyTips } from "@/lib/calculations";
import { localDateKey } from "@/lib/store";

const DAYS = ["Domenica", "Lunedì", "Martedì", "Mercoledì", "Giovedì", "Venerdì", "Sabato"];

function todayKey() {
  return new Date().getDay();
}

function dateKey() {
  return localDateKey();
}

function recentStartKey() {
  return localDateKey(new Date(Date.now() - 6 * 86400000));
}

export default function HomePage() {
  const { data, loaded, save } = useFitnessData();
  const today = todayKey();
  const todayMeals = data.plan?.meals[String(today)] ?? [];
  const todayMealStatus = data.dailyMealStatus[dateKey()] ?? {};
  const log = data.dailyNutrition[dateKey()] ?? { calories: 0, protein: 0, carbs: 0, fat: 0 };
  const workout = data.plan?.workouts.find((item) => item.dayOfWeek === today);
  const completedWorkouts = data.workoutLogs.filter((item) => item.date.slice(0, 10) >= recentStartKey()).length;
  const name = data.profile.name.trim() || "atleta";
  const progress = data.plan ? Math.min(100, Math.round((completedWorkouts / Math.max(1, data.profile.trainingDays)) * 100)) : 0;
  const dailyTip = getDailyTips(data.profile.goal)[new Date().getDate() % getDailyTips(data.profile.goal).length];

  const markMeal = (mealId: string) => {
    if (!data.plan) return;
    save((current) => {
      const meal = Object.values(current.plan!.meals).flat().find((item) => item.id === mealId);
      if (!meal) return current;
      const key = dateKey();
      const wasConsumed = Boolean(current.dailyMealStatus[key]?.[mealId]);
      const currentLog = current.dailyNutrition[key] ?? { calories: 0, protein: 0, carbs: 0, fat: 0 };
      const nextLog = wasConsumed
        ? { calories: Math.max(0, currentLog.calories - meal.calories), protein: Math.max(0, currentLog.protein - meal.protein), carbs: Math.max(0, currentLog.carbs - meal.carbs), fat: Math.max(0, currentLog.fat - meal.fat) }
        : { calories: currentLog.calories + meal.calories, protein: currentLog.protein + meal.protein, carbs: currentLog.carbs + meal.carbs, fat: currentLog.fat + meal.fat };
      const nextDayStatus = { ...(current.dailyMealStatus[key] ?? {}), [mealId]: !wasConsumed };
      return { ...current, dailyMealStatus: { ...current.dailyMealStatus, [key]: nextDayStatus }, dailyNutrition: { ...current.dailyNutrition, [key]: nextLog } };
    });
  };

  if (!loaded) return <div className="grid min-h-screen place-items-center text-sm text-slate-500">Caricamento…</div>;

  return (
    <div className="mx-auto max-w-3xl px-4 pt-5 sm:px-6">
      <header className="mb-5 flex items-start justify-between gap-3">
        <div>
          <p className="text-sm font-medium text-slate-500">Buon allenamento 👋</p>
          <h1 className="mt-1 text-3xl font-black tracking-tight text-slate-950">Ciao {name}</h1>
        </div>
        <Link href="/profile" className="grid h-12 w-12 place-items-center rounded-2xl bg-slate-900 text-sm font-black text-white shadow-lg">{name.charAt(0).toUpperCase()}</Link>
      </header>

      {!data.plan && (
        <section className="mb-5 overflow-hidden rounded-3xl bg-gradient-to-br from-blue-600 to-indigo-700 p-5 text-white shadow-xl">
          <div className="flex items-start gap-4">
            <div className="grid h-12 w-12 shrink-0 place-items-center rounded-2xl bg-white/15"><Sparkles size={24} /></div>
            <div>
              <p className="text-xs font-bold uppercase tracking-[0.18em] text-blue-100">Piano personale</p>
              <h2 className="mt-1 text-2xl font-black">Completa il profilo e genera la settimana.</h2>
              <p className="mt-2 text-sm leading-6 text-blue-50">L'app prepara workout, pasti e una routine di supporto, poi li puoi modificare e tracciare giorno per giorno.</p>
              <Link href="/profile" className="mt-4 inline-flex items-center gap-2 rounded-xl bg-white px-4 py-3 text-sm font-bold text-blue-700">Configura profilo <ArrowRight size={16} /></Link>
            </div>
          </div>
        </section>
      )}

      {data.plan && (
        <section className="mb-5 grid grid-cols-2 gap-3 sm:grid-cols-4">
          <div className="rounded-2xl bg-white p-4 shadow-sm ring-1 ring-slate-200"><Target size={18} className="text-blue-600" /><p className="mt-3 text-2xl font-black">{data.plan.nutrition.calories}</p><p className="text-xs font-semibold text-slate-500">kcal / giorno</p></div>
          <div className="rounded-2xl bg-white p-4 shadow-sm ring-1 ring-slate-200"><Flame size={18} className="text-orange-500" /><p className="mt-3 text-2xl font-black">{data.plan.nutrition.protein}g</p><p className="text-xs font-semibold text-slate-500">proteine</p></div>
          <div className="rounded-2xl bg-white p-4 shadow-sm ring-1 ring-slate-200"><Trophy size={18} className="text-violet-600" /><p className="mt-3 text-2xl font-black">{completedWorkouts}</p><p className="text-xs font-semibold text-slate-500">workout 7 giorni</p></div>
          <div className="rounded-2xl bg-white p-4 shadow-sm ring-1 ring-slate-200"><Zap size={18} className="text-emerald-600" /><p className="mt-3 text-2xl font-black">{progress}%</p><p className="text-xs font-semibold text-slate-500">settimana</p></div>
        </section>
      )}

      <section className="mb-5 rounded-3xl bg-slate-950 p-5 text-white shadow-xl">
        <div className="flex items-center justify-between gap-3">
          <div><p className="text-xs font-bold uppercase tracking-[0.18em] text-slate-400">Oggi · {DAYS[today]}</p><h2 className="mt-1 text-2xl font-black">{workout?.name ?? "Recupero / riposo"}</h2></div>
          <CalendarDays className="text-slate-400" />
        </div>
        {workout ? (
          <Link href="/workout" className="mt-5 flex items-center justify-between rounded-2xl bg-white/10 p-4 transition hover:bg-white/15">
            <span><span className="block text-sm font-bold">{workout.exercises.length} esercizi</span><span className="mt-1 block text-xs text-slate-300">Circa {workout.durationMinutes} min · {workout.focus}</span></span>
            <span className="grid h-10 w-10 place-items-center rounded-xl bg-blue-600"><ChevronRight size={18} /></span>
          </Link>
        ) : <p className="mt-4 text-sm text-slate-300">Il piano lascia spazio al recupero tra le sessioni.</p>}
      </section>

      {data.plan && (
        <section className="mb-5 rounded-3xl bg-white p-5 shadow-sm ring-1 ring-slate-200">
          <div className="mb-4 flex items-center justify-between"><div><p className="text-xs font-bold uppercase tracking-[0.15em] text-slate-400">Nutrizione</p><h2 className="mt-1 text-xl font-black">Oggi nel piatto</h2></div><Link href="/nutrition" className="text-sm font-bold text-blue-600">Apri <ArrowRight size={15} className="inline" /></Link></div>
          <div className="mb-5 grid grid-cols-4 gap-2 text-center text-xs"><div><b className="text-base text-slate-950">{log.calories}</b><span className="block text-slate-400">/ {data.plan.nutrition.calories} kcal</span></div><div><b className="text-base text-slate-950">{log.protein}g</b><span className="block text-slate-400">proteine</span></div><div><b className="text-base text-slate-950">{log.carbs}g</b><span className="block text-slate-400">carbo</span></div><div><b className="text-base text-slate-950">{log.fat}g</b><span className="block text-slate-400">grassi</span></div></div>
          <div className="space-y-2">
            {todayMeals.slice(0, 4).map((meal) => {
              const consumed = Boolean(todayMealStatus[meal.id]);
              return (
                <button type="button" key={meal.id} onClick={() => markMeal(meal.id)} className={`flex w-full items-center gap-3 rounded-2xl border p-3 text-left transition ${consumed ? "border-emerald-200 bg-emerald-50" : "border-slate-200 bg-slate-50"}`}>
                  <span className={`grid h-10 w-10 place-items-center rounded-xl ${consumed ? "bg-emerald-500 text-white" : "bg-white text-slate-400"}`}><Utensils size={17} /></span>
                  <span className="min-w-0 flex-1"><span className="block text-xs font-bold uppercase text-slate-400">{meal.meal}</span><span className={`mt-0.5 block truncate text-sm font-bold ${consumed ? "line-through text-emerald-700" : "text-slate-900"}`}>{meal.name}</span></span>
                  <CheckCircle2 size={20} className={consumed ? "text-emerald-600" : "text-slate-300"} />
                </button>
              );
            })}
          </div>
        </section>
      )}

      <section className="mb-4 rounded-3xl bg-white p-5 shadow-sm ring-1 ring-slate-200">
        <div className="flex items-center gap-3"><span className="grid h-11 w-11 place-items-center rounded-2xl bg-blue-50 text-blue-600"><Bot size={22} /></span><div><p className="text-xs font-bold uppercase tracking-[0.15em] text-slate-400">AI Coach</p><h2 className="text-xl font-black">{dailyTip}</h2></div></div>
      </section>

      <div className="grid gap-3 pb-2 sm:grid-cols-2">
        <Link href="/workout" className="rounded-2xl bg-blue-600 p-4 text-white shadow-lg"><span className="flex items-center justify-between text-sm font-bold">Vai al workout <ArrowRight size={17} /></span></Link>
        <Link href="/profile" className="rounded-2xl bg-white p-4 text-slate-900 ring-1 ring-slate-200"><span className="flex items-center justify-between text-sm font-bold">Aggiorna obiettivo <ArrowRight size={17} /></span></Link>
      </div>
    </div>
  );
}
