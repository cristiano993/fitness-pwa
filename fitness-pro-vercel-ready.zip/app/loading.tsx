export default function Loading() {
  return (
    <main className="min-h-screen bg-slate-50 px-4 pb-24 pt-16 dark:bg-slate-950" aria-busy="true">
      <section className="mx-auto max-w-4xl space-y-4">
        <div className="h-10 w-48 animate-pulse rounded-2xl bg-slate-200 dark:bg-slate-800" />
        <div className="h-5 w-72 animate-pulse rounded-xl bg-slate-200 dark:bg-slate-800" />
        <div className="grid gap-4 md:grid-cols-3">
          {[1, 2, 3].map((item) => <div key={item} className="h-32 animate-pulse rounded-3xl bg-white shadow-sm dark:bg-slate-900" />)}
        </div>
      </section>
    </main>
  );
}
