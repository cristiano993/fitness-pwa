import type { Metadata, Viewport } from "next";
import "./globals.css";
import BottomNav from "@/components/BottomNav";
import PWAInstaller from "@/components/PWAInstaller";
import ServiceWorkerRegister from "@/components/ServiceWorkerRegister";

export const metadata: Metadata = {
  title: "Fitness Pro · Piano personale",
  description: "Allenamento, nutrizione e integratori in un'unica PWA.",
  manifest: "/manifest.json",
  applicationName: "Fitness Pro",
  icons: { icon: "/icon-192.png", apple: "/icon-192.png" },
  appleWebApp: { capable: true, title: "Fitness Pro", statusBarStyle: "black-translucent" },
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  viewportFit: "cover",
  themeColor: "#0f172a",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="it">
      <body>
        <PWAInstaller />
        <ServiceWorkerRegister />
        <main className="min-h-screen pb-24">{children}</main>
        <BottomNav />
      </body>
    </html>
  );
}
