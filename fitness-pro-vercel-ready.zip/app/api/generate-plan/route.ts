import { NextResponse } from "next/server";
import { sanitizeAiPlan } from "@/lib/plan";
import type { UserProfile } from "@/lib/types";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const requestLog = new Map<string, { count: number; resetAt: number }>();
const WINDOW_MS = 60 * 60 * 1000;
const MAX_REQUESTS = 8;

function clientKey(request: Request): string {
  return request.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "anonymous";
}

function isProfile(value: unknown): value is UserProfile {
  if (!value || typeof value !== "object") return false;
  const profile = value as Record<string, unknown>;
  const finite = (input: unknown) => typeof input === "number" && Number.isFinite(input);
  const shortString = (input: unknown, max = 500) => typeof input === "string" && input.trim().length <= max;
  return (
    shortString(profile.name, 80) &&
    finite(profile.age) && profile.age >= 13 && profile.age <= 100 &&
    finite(profile.height) && profile.height >= 120 && profile.height <= 240 &&
    finite(profile.weight) && profile.weight >= 30 && profile.weight <= 300 &&
    (profile.sex === "M" || profile.sex === "F") &&
    ["Ipertrofia", "Forza", "Definizione", "Mantenimento"].includes(String(profile.goal)) &&
    finite(profile.trainingDays) && Number.isInteger(profile.trainingDays) && profile.trainingDays >= 1 && profile.trainingDays <= 7 &&
    shortString(profile.experience, 40) &&
    shortString(profile.location, 40) &&
    shortString(profile.equipment, 300) &&
    shortString(profile.diet, 40) &&
    shortString(profile.restrictions, 1000)
  );
}

const schema = {
  type: "object",
  additionalProperties: false,
  properties: {
    id: { type: "string" },
    title: { type: "string" },
    summary: { type: "string" },
    nutrition: {
      type: "object",
      additionalProperties: false,
      properties: {
        calories: { type: "number" },
        protein: { type: "number" },
        carbs: { type: "number" },
        fat: { type: "number" },
      },
      required: ["calories", "protein", "carbs", "fat"],
    },
    workouts: {
      type: "array",
      items: {
        type: "object",
        additionalProperties: false,
        properties: {
          id: { type: "string" },
          name: { type: "string" },
          dayOfWeek: { type: "number" },
          focus: { type: "string" },
          durationMinutes: { type: "number" },
          exercises: {
            type: "array",
            items: {
              type: "object",
              additionalProperties: false,
              properties: {
                id: { type: "string" },
                name: { type: "string" },
                sets: { type: "number" },
                reps: { type: "string" },
                weight: { type: "number" },
                restSeconds: { type: "number" },
                rpe: { type: "number" },
                notes: { type: "string" },
              },
              required: ["id", "name", "sets", "reps", "weight", "restSeconds", "rpe", "notes"],
            },
          },
        },
        required: ["id", "name", "dayOfWeek", "focus", "durationMinutes", "exercises"],
      },
    },
    mealDays: {
      type: "array",
      items: {
        type: "object",
        additionalProperties: false,
        properties: {
          dayOfWeek: { type: "number" },
          meals: {
            type: "array",
            items: {
              type: "object",
              additionalProperties: false,
              properties: {
                id: { type: "string" },
                meal: { type: "string" },
                name: { type: "string" },
                calories: { type: "number" },
                protein: { type: "number" },
                carbs: { type: "number" },
                fat: { type: "number" },
                items: { type: "array", items: { type: "string" } },
              },
              required: ["id", "meal", "name", "calories", "protein", "carbs", "fat", "items"],
            },
          },
        },
        required: ["dayOfWeek", "meals"],
      },
    },
    supplements: {
      type: "array",
      items: {
        type: "object",
        additionalProperties: false,
        properties: {
          id: { type: "string" },
          name: { type: "string" },
          dosage: { type: "string" },
          timing: { type: "string" },
          notes: { type: "string" },
        },
        required: ["id", "name", "dosage", "timing", "notes"],
      },
    },
    notes: { type: "array", items: { type: "string" } },
  },
  required: ["id", "title", "summary", "nutrition", "workouts", "mealDays", "supplements", "notes"],
} as const;

function fallbackResponse(profile: UserProfile, status = 200) {
  const plan = sanitizeAiPlan(null, profile);
  return NextResponse.json({ plan, source: "fallback", message: "AI non configurata: è stato creato un piano locale." }, { status });
}

export async function POST(request: Request) {
  let profile: UserProfile | null = null;
  const key = clientKey(request);
  const now = Date.now();
  const current = requestLog.get(key);
  if (!current || now >= current.resetAt) {
    requestLog.set(key, { count: 1, resetAt: now + WINDOW_MS });
  } else if (current.count >= MAX_REQUESTS) {
    return NextResponse.json({ error: "Limite temporaneo raggiunto. Riprova più tardi." }, { status: 429 });
  } else {
    current.count += 1;
  }

  let timeout: ReturnType<typeof setTimeout> | undefined;
  try {
    const rawBody = await request.text();
    if (rawBody.length > 60_000) {
      return NextResponse.json({ error: "Richiesta troppo grande." }, { status: 413 });
    }

    const parsed = JSON.parse(rawBody) as { profile?: unknown };
    if (!isProfile(parsed.profile)) {
      return NextResponse.json({ error: "Profilo incompleto o non valido." }, { status: 400 });
    }
    profile = parsed.profile;

    if (!process.env.OPENAI_API_KEY) {
      return fallbackResponse(profile);
    }

    const model = process.env.OPENAI_MODEL || "gpt-5-mini";
    const prompt = `Crea un piano fitness settimanale in italiano, pratico e leggibile su smartphone. Usa ESCLUSIVAMENTE i dati del profilo. Il piano deve includere: ${profile.trainingDays} allenamenti; esercizi con serie, ripetizioni, recupero, RPE e note tecniche; target calorie e macro; 4-6 pasti al giorno per ogni giorno; integratori solo come supporto non farmacologico e con note di prudenza. Non prescrivere farmaci, non fare diagnosi, non ignorare allergie o restrizioni. Obiettivo: ${profile.goal}. Esperienza: ${profile.experience}. Luogo: ${profile.location}. Attrezzatura: ${profile.equipment}. Dieta: ${profile.diet}. Restrizioni/allergie dichiarate: ${profile.restrictions || "nessuna dichiarata"}. Peso: ${profile.weight} kg. Altezza: ${profile.height} cm. Età: ${profile.age}. Sesso: ${profile.sex}. Se un dato manca, fai una proposta conservativa e rendila esplicita. Restituisci SOLO il JSON richiesto dallo schema.`;

    const controller = new AbortController();
    timeout = setTimeout(() => controller.abort(), 45_000);
    const upstream = await fetch("https://api.openai.com/v1/responses", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${process.env.OPENAI_API_KEY}`,
      },
      signal: controller.signal,
      body: JSON.stringify({
        model,
        input: [
          { role: "system", content: "Sei un assistente per fitness e nutrizione. Fornisci un piano pratico senza sostituire professionisti sanitari." },
          { role: "user", content: prompt },
        ],
        text: {
          format: {
            type: "json_schema",
            name: "fitness_weekly_plan",
            strict: true,
            schema,
          },
        },
      }),
    });

    clearTimeout(timeout);
    timeout = undefined;

    if (!upstream.ok) {
      const detail = await upstream.text();
      console.error("OpenAI API error:", upstream.status, detail.slice(0, 1000));
      return fallbackResponse(profile);
    }

    const body = (await upstream.json()) as Record<string, unknown>;
    const outputText = typeof body.output_text === "string" ? body.output_text : extractOutputText(body.output);
    if (!outputText) return fallbackResponse(profile);

    let generated: unknown;
    try {
      generated = JSON.parse(outputText);
    } catch {
      console.error("Risposta AI non JSON.");
      return fallbackResponse(profile);
    }

    const plan = sanitizeAiPlan(generated, profile);
    return NextResponse.json({ plan, source: "ai" });
  } catch (error) {
    if (timeout) clearTimeout(timeout);
    console.error("Errore generazione piano:", error);
    return profile ? fallbackResponse(profile) : NextResponse.json({ error: "Impossibile leggere il profilo." }, { status: 400 });
  }
}

function extractOutputText(output: unknown): string | null {
  if (!Array.isArray(output)) return null;
  for (const item of output) {
    if (!item || typeof item !== "object") continue;
    const record = item as Record<string, unknown>;
    const content = record.content;
    if (!Array.isArray(content)) continue;
    for (const part of content) {
      if (!part || typeof part !== "object") continue;
      const partRecord = part as Record<string, unknown>;
      if (partRecord.type === "output_text" && typeof partRecord.text === "string") return partRecord.text;
    }
  }
  return null;
}
