"use client";

import { useMemo, useState } from "react";
import type { FormEvent } from "react";
import { Apple, Check, Plus, Utensils } from "lucide-react";
import { useFitnessData } from "@/hooks/useFitnessData";
import { localDateKey } from "@/lib/store";
import type { MealPlanItem } from "@/lib/types";

const todayKey = () => new Date().getDay().toString();
const logKey = () => localDateKey();

export default function NutritionPage() {
  const { data, loaded, save } = useFitnessData();
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ name: "", calories: "", protein: "", carbs: "", fat: "" });
  const todayMeals = data.plan?.meals[todayKey()] ?? [];
  const log = data.dailyNutrition[logKey()] ?? { calories: 0, protein: 0, carbs: 0, fat: 0 };
  const target = data.plan?.nutrition;

  const totals = useMemo(() => target ? [
    ["Calorie", log.calories, target.calories, "kcal"],
    ["Proteine", log.protein, target.protein, "g"],
    ["Carboidrati", log.carbs, target.carbs, "g"],
    ["Grassi", log.fat, target.fat, "g"],
  ] as const : [], [log, target]);

  const toggleMeal = (meal: MealPlanItem) => {
    save((current) => {
      const key = logKey();
      const wasConsumed = Boolean(current.dailyMealStatus[key]?.[meal.id]);
      const currentLog = current.dailyNutrition[key] ?? { calories: 0, protein: 0, carbs: 0, fat: 0 };
      const nextLog = wasConsumed
        ? { calories: Math.max(0, currentLog.calories - meal.calories), protein: Math.max(0, currentLog.protein - meal.protein), carbs: Math.max(0, currentLog.carbs - meal.carbs), fat: Math.max(0, currentLog.fat - meal.fat) }
        : { calories: currentLog.calories + meal.calories, protein: currentLog.protein + meal.protein, carbs: currentLog.carbs + meal.carbs, fat: currentLog.fat + meal.fat };
      const nextDayStatus = { ...(current.dailyMealStatus[key] ?? {}), [meal.id]: !wasConsumed };
      return { ...current, dailyMealStatus: { ...current.dailyMealStatus, [key]: nextDayStatus }, dailyNutrition: { ...current.dailyNutrition, [key]: nextLog } };
    });
  };

  const addCustomMeal = (event: FormEvent) => {
    event.preventDefault();
    const meal: MealPlanItem = { id: `custom-${Date.now()}`, date: logKey(), meal: "Personalizzato", name: form.name || "Pasto personalizzato", calories: Number(form.calories) || 0, protein: Number(form.protein) || 0, carbs: Number(form.carbs) || 0, fat: Number(form.fat) || 0, items: [form.name || "Pasto personalizzato"], consumed: false };
    save((current) => ({ ...current, customMeals: [...current.customMeals, meal] }));
    setForm({ name: "", calories: "", protein: "", carbs: "", fat: "" });
    setShowForm(false);
  };

  if (!loaded) return <div className="grid min-h-screen place-items-center text-sm text-slate-500">Caricamento…</div>;
  if (!target) return <div className="mx-auto max-w-3xl px-4 pt-8"><div className="rounded-3xl bg-white p-6 text-center shadow-sm ring-1 ring-slate-200"><Apple className="mx-auto text-emerald-600" size={36} /><h1 className="mt-4 text-2xl font-black">Nutrizione non ancora configurata</h1><p className="mt-2 text-sm text-slate-500">Genera il piano dal Profilo per avere target e pasti personalizzati.</p></div></div>;

  const pct = (value: number, max: number) => Math.min(100, Math.round((value / Math.max(1, max)) * 100));
  const allMeals = [...todayMeals, ...data.customMeals.filter((meal) => meal.date === logKey())];

  return (
    <div className="mx-auto max-w-3xl px-4 pt-5 sm:px-6">
      <header className="mb-5 flex items-end justify-between"><div><p className="text-sm font-medium text-slate-500">Piano del giorno</p><h1 className="text-3xl font-black tracking-tight">Nutrizione</h1></div><span className="grid h-12 w-12 place-items-center rounded-2xl bg-emerald-600 text-white"><Apple size={22} /></span></header>
      <section className="mb-5 rounded-3xl bg-white p-5 shadow-sm ring-1 ring-slate-200"><div className="mb-5 flex items-center justify-between"><div><p className="text-xs font-bold uppercase tracking-[0.16em] text-slate-400">Target</p><p className="mt-1 text-3xl font-black">{log.calories} <span className="text-base text-slate-400">/ {target.calories} kcal</span></p></div><div className="text-right text-xs font-bold text-slate-500">{pct(log.calories, target.calories)}%</div></div><div className="mb-5 h-3 overflow-hidden rounded-full bg-slate-100"><div className="h-full rounded-full bg-emerald-500 transition-all" style={{ width: `${pct(log.calories, target.calories)}%` }} /></div><div className="grid grid-cols-3 gap-3">{totals.slice(1).map(([label, value, max, unit]) => <div key={label} className="rounded-2xl bg-slate-50 p-3"><p className="text-xs font-bold text-slate-400">{label}</p><p className="mt-1 text-lg font-black">{value}{unit === "g" ? "g" : ""}</p><p className="text-[11px] text-slate-400">target {max}{unit}</p></div>)}</div></section>
      <section className="mb-5"><div className="mb-3 flex items-center justify-between"><div><p className="text-xs font-bold uppercase tracking-[0.16em] text-slate-400">Oggi</p><h2 className="mt-1 text-xl font-black">Pasti programmati</h2></div><button type="button" onClick={() => setShowForm((open) => !open)} className="inline-flex items-center gap-1 rounded-xl bg-slate-900 px-3 py-2 text-xs font-bold text-white"><Plus size={15} /> Aggiungi</button></div><div className="space-y-3">{allMeals.length ? allMeals.map((meal) => { const consumed = Boolean(data.dailyMealStatus[logKey()]?.[meal.id]); return <button type="button" key={meal.id} onClick={() => toggleMeal(meal)} className={`w-full rounded-2xl border p-4 text-left transition ${consumed ? "border-emerald-200 bg-emerald-50" : "border-slate-200 bg-white"}`}><div className="flex items-start gap-3"><span className={`grid h-10 w-10 shrink-0 place-items-center rounded-xl ${consumed ? "bg-emerald-500 text-white" : "bg-slate-100 text-slate-500"}`}><Utensils size={17} /></span><span className="min-w-0 flex-1"><span className="block text-[11px] font-bold uppercase tracking-wide text-slate-400">{meal.meal}</span><span className="mt-1 block text-sm font-black">{meal.name}</span><span className="mt-2 block text-xs text-slate-500">{meal.calories} kcal · {meal.protein}g P · {meal.carbs}g C · {meal.fat}g F</span></span><Check size={18} className={consumed ? "text-emerald-600" : "text-slate-300"} /></div>{meal.items.length > 0 && <div className="mt-3 flex flex-wrap gap-1.5">{meal.items.slice(0, 5).map((item) => <span key={item} className="rounded-full bg-slate-100 px-2 py-1 text-[10px] font-semibold text-slate-500">{item}</span>)}</div>}</button>; }) : <div className="rounded-2xl border border-dashed border-slate-300 p-6 text-center text-sm text-slate-500">Nessun pasto programmato per oggi.</div>}</div></section>
      {showForm && <form onSubmit={addCustomMeal} className="mb-5 rounded-3xl bg-white p-5 shadow-sm ring-1 ring-slate-200"><h2 className="text-lg font-black">Pasto personalizzato</h2><div className="mt-4 grid gap-3 sm:grid-cols-2"><input required placeholder="Nome pasto" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className="rounded-xl border border-slate-200 px-3 py-3 text-sm" /><input required type="number" min="0" placeholder="Calorie" value={form.calories} onChange={(e) => setForm({ ...form, calories: e.target.value })} className="rounded-xl border border-slate-200 px-3 py-3 text-sm" /><input type="number" min="0" placeholder="Proteine (g)" value={form.protein} onChange={(e) => setForm({ ...form, protein: e.target.value })} className="rounded-xl border border-slate-200 px-3 py-3 text-sm" /><input type="number" min="0" placeholder="Carboidrati (g)" value={form.carbs} onChange={(e) => setForm({ ...form, carbs: e.target.value })} className="rounded-xl border border-slate-200 px-3 py-3 text-sm" /><input type="number" min="0" placeholder="Grassi (g)" value={form.fat} onChange={(e) => setForm({ ...form, fat: e.target.value })} className="rounded-xl border border-slate-200 px-3 py-3 text-sm" /></div><button className="mt-4 w-full rounded-xl bg-emerald-600 px-4 py-3 text-sm font-black text-white">Salva pasto</button></form>}
      <p className="pb-4 text-center text-xs leading-5 text-slate-400">I valori nutrizionali sono stime del piano e possono variare in base agli alimenti e alle quantità reali.</p>
    </div>
  );
}
