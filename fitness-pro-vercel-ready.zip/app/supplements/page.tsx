"use client";

import { useState } from "react";
import { CheckCircle2, Info, Pill, Plus, RotateCcw } from "lucide-react";
import { useFitnessData } from "@/hooks/useFitnessData";
import { localDateKey } from "@/lib/store";
import type { SupplementPlanItem } from "@/lib/types";

export default function SupplementsPage() {
  const { data, loaded, save } = useFitnessData();
  const [formOpen, setFormOpen] = useState(false);
  const [form, setForm] = useState({ name: "", dosage: "", timing: "" });
  const today = localDateKey();
  const supplements = data.supplements.length ? data.supplements : data.plan?.supplements ?? [];

  const toggle = (id: string) => save((current) => ({ ...current, supplements: (current.supplements.length ? current.supplements : current.plan?.supplements ?? []).map((item) => {
    if (item.id !== id) return item;
    const completedToday = item.completedDate === today;
    return { ...item, completed: !completedToday, completedDate: completedToday ? undefined : today };
  }) }));
  const reset = () => save((current) => ({ ...current, supplements: supplements.map((item) => ({ ...item, completed: false, completedDate: undefined })) }));
  const add = () => {
    if (!form.name.trim()) return;
    const item: SupplementPlanItem = { id: `supp-${Date.now()}`, name: form.name.trim(), dosage: form.dosage || "Segui etichetta", timing: form.timing || "Quando indicato", notes: "Verifica sempre etichetta, tolleranza e compatibilità con le tue esigenze.", completed: false };
    save((current) => ({ ...current, supplements: [...supplements, item] }));
    setForm({ name: "", dosage: "", timing: "" });
    setFormOpen(false);
  };

  if (!loaded) return <div className="grid min-h-screen place-items-center text-sm text-slate-500">Caricamento…</div>;
  if (!data.plan) return <div className="mx-auto max-w-3xl px-4 pt-8"><div className="rounded-3xl bg-white p-6 text-center shadow-sm ring-1 ring-slate-200"><Pill className="mx-auto text-violet-600" size={36} /><h1 className="mt-4 text-2xl font-black">Integratori</h1><p className="mt-2 text-sm text-slate-500">Genera il tuo piano per avere una routine collegata all'obiettivo.</p></div></div>;

  const completed = supplements.filter((item) => item.completedDate === today).length;
  return (
    <div className="mx-auto max-w-3xl px-4 pt-5 sm:px-6">
      <header className="mb-5 flex items-end justify-between"><div><p className="text-sm font-medium text-slate-500">Routine giornaliera</p><h1 className="text-3xl font-black tracking-tight">Integratori</h1></div><button type="button" onClick={reset} aria-label="Resetta completamenti" className="grid h-11 w-11 place-items-center rounded-xl bg-white text-slate-400 ring-1 ring-slate-200"><RotateCcw size={18} /></button></header>
      <section className="mb-5 rounded-3xl bg-violet-950 p-5 text-white shadow-xl"><div className="flex items-center gap-3"><span className="grid h-11 w-11 place-items-center rounded-2xl bg-white/10"><Pill size={21} /></span><div><p className="text-xs font-bold uppercase tracking-[0.16em] text-violet-300">Checklist</p><p className="text-2xl font-black">{completed}/{supplements.length} completati</p></div></div><div className="mt-4 h-2 overflow-hidden rounded-full bg-white/10"><div className="h-full rounded-full bg-violet-400" style={{ width: `${supplements.length ? (completed / supplements.length) * 100 : 0}%` }} /></div></section>
      <div className="space-y-3">{supplements.map((item) => { const completedToday = item.completedDate === today; return <button type="button" key={item.id} onClick={() => toggle(item.id)} className={`w-full rounded-2xl border p-4 text-left transition ${completedToday ? "border-violet-200 bg-violet-50" : "border-slate-200 bg-white"}`}><div className="flex items-start gap-3"><span className={`mt-0.5 grid h-10 w-10 shrink-0 place-items-center rounded-xl ${completedToday ? "bg-violet-600 text-white" : "bg-slate-100 text-slate-500"}`}><Pill size={17} /></span><span className="min-w-0 flex-1"><span className={`block text-sm font-black ${completedToday ? "text-violet-800" : "text-slate-900"}`}>{item.name}</span><span className="mt-1 block text-xs font-semibold text-slate-500">{item.dosage} · {item.timing}</span><span className="mt-2 block text-xs leading-5 text-slate-500">{item.notes}</span></span><CheckCircle2 size={20} className={completedToday ? "text-violet-600" : "text-slate-300"} /></div></button>; })}</div>
      <button type="button" onClick={() => setFormOpen((open) => !open)} className="mt-4 flex w-full items-center justify-center gap-2 rounded-2xl bg-slate-900 px-4 py-4 text-sm font-black text-white"><Plus size={17} /> Aggiungi integratore</button>
      {formOpen && <div className="mt-4 rounded-3xl bg-white p-5 shadow-sm ring-1 ring-slate-200"><h2 className="text-lg font-black">Nuovo elemento</h2><div className="mt-4 space-y-3"><input placeholder="Nome" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className="w-full rounded-xl border border-slate-200 px-3 py-3 text-sm" /><input placeholder="Dose" value={form.dosage} onChange={(e) => setForm({ ...form, dosage: e.target.value })} className="w-full rounded-xl border border-slate-200 px-3 py-3 text-sm" /><input placeholder="Quando" value={form.timing} onChange={(e) => setForm({ ...form, timing: e.target.value })} className="w-full rounded-xl border border-slate-200 px-3 py-3 text-sm" /><button type="button" onClick={add} className="w-full rounded-xl bg-violet-600 px-4 py-3 text-sm font-black text-white">Salva</button></div></div>}
      <div className="mt-5 rounded-2xl bg-amber-50 p-4 text-xs leading-5 text-amber-900"><Info className="mb-1 inline" size={14} /> Gli integratori non sono obbligatori. Verifica sempre etichetta, tolleranza, possibili interazioni e la tua situazione personale con un professionista sanitario.</div>
      <p className="pb-4 pt-4 text-center text-xs text-slate-400">Questa sezione non sostituisce un parere medico o nutrizionale.</p>
    </div>
  );
}
