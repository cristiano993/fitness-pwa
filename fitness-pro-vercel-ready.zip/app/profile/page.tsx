"use client";

import { useMemo, useState } from "react";
import type { ChangeEvent } from "react";
import { Download, FileJson, Save, ShieldCheck, Sparkles, Upload, UserRound } from "lucide-react";
import { useFitnessData } from "@/hooks/useFitnessData";
import { localDateKey, updateProfile } from "@/lib/store";
import type { Experience, Goal, TrainingLocation, DietStyle } from "@/lib/types";

const goals: { value: Goal; label: string }[] = [
  { value: "Ipertrofia", label: "Aumentare massa muscolare" },
  { value: "Forza", label: "Aumentare forza" },
  { value: "Definizione", label: "Ridurre grasso" },
  { value: "Mantenimento", label: "Mantenere forma" },
];

export default function ProfilePage() {
  const { data, loaded, save, reset } = useFitnessData();
  const [status, setStatus] = useState<string>("");
  const [generating, setGenerating] = useState(false);

  const profileReady = useMemo(() => data.profile.age >= 14 && data.profile.age <= 100 && data.profile.height >= 120 && data.profile.weight >= 35, [data.profile]);

  const patch = <K extends keyof typeof data.profile>(key: K, value: (typeof data.profile)[K]) => {
    save((current) => updateProfile(current, { [key]: value }));
  };

  const generatePlan = async () => {
    if (!profileReady) {
      setStatus("Controlla età, altezza e peso prima di generare il piano.");
      return;
    }
    setGenerating(true);
    setStatus("");
    try {
      const response = await fetch("/api/generate-plan", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ profile: data.profile }) });
      const result = (await response.json()) as { plan?: typeof data.plan; message?: string; error?: string };
      if (!response.ok || !result.plan) throw new Error(result.error || "Generazione non riuscita");
      save((current) => ({ ...current, plan: result.plan!, supplements: result.plan!.supplements, weightHistory: [...current.weightHistory.filter((item) => item.date !== localDateKey()), { date: localDateKey(), weight: current.profile.weight }] }));
      setStatus(result.message || (result.plan.source === "ai" ? "Piano AI generato e salvato." : "Piano locale generato. Configura OPENAI_API_KEY su Vercel per usare l'AI."));
    } catch (error) {
      setStatus(error instanceof Error ? error.message : "Errore durante la generazione.");
    } finally {
      setGenerating(false);
    }
  };

  const exportData = () => {
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = `fitness-backup-${localDateKey()}.json`;
    anchor.click();
    URL.revokeObjectURL(url);
  };

  const importData = (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const parsed = JSON.parse(String(reader.result)) as typeof data;
        if (!parsed || !parsed.profile) throw new Error("Backup non valido.");
        save({ ...parsed, version: 3 });
        setStatus("Backup ripristinato.");
      } catch (error) {
        setStatus(error instanceof Error ? error.message : "Backup non valido.");
      }
    };
    reader.readAsText(file);
    event.target.value = "";
  };

  if (!loaded) return <div className="grid min-h-screen place-items-center text-sm text-slate-500">Caricamento…</div>;

  const fieldClass = "mt-1 w-full rounded-xl border border-slate-200 bg-white px-3 py-3 text-sm font-medium text-slate-900";
  const labelClass = "text-xs font-bold uppercase tracking-wide text-slate-500";

  return (
    <div className="mx-auto max-w-3xl px-4 pt-5 sm:px-6">
      <div className="mb-5 flex items-start gap-3"><div className="grid h-12 w-12 place-items-center rounded-2xl bg-blue-600 text-white"><UserRound size={22} /></div><div><p className="text-sm font-medium text-slate-500">Personalizzazione</p><h1 className="text-3xl font-black tracking-tight">Il tuo profilo</h1></div></div>

      <section className="mb-5 rounded-3xl bg-white p-5 shadow-sm ring-1 ring-slate-200">
        <div className="mb-4 flex items-center justify-between"><h2 className="text-lg font-black">Dati di base</h2><Save size={18} className="text-blue-600" /></div>
        <div className="grid gap-4 sm:grid-cols-2">
          <label className={labelClass}>Nome<input className={fieldClass} value={data.profile.name} onChange={(e) => patch("name", e.target.value)} placeholder="Come ti chiami?" /></label>
          <label className={labelClass}>Età<input className={fieldClass} type="number" min="14" max="100" value={data.profile.age} onChange={(e) => patch("age", Number(e.target.value))} /></label>
          <label className={labelClass}>Altezza (cm)<input className={fieldClass} type="number" min="120" max="230" value={data.profile.height} onChange={(e) => patch("height", Number(e.target.value))} /></label>
          <label className={labelClass}>Peso (kg)<input className={fieldClass} type="number" min="35" max="300" step="0.1" value={data.profile.weight} onChange={(e) => patch("weight", Number(e.target.value))} /></label>
          <label className={labelClass}>Sesso<select className={fieldClass} value={data.profile.sex} onChange={(e) => patch("sex", e.target.value as "M" | "F")}><option value="M">Uomo</option><option value="F">Donna</option></select></label>
          <label className={labelClass}>Esperienza<select className={fieldClass} value={data.profile.experience} onChange={(e) => patch("experience", e.target.value as Experience)}><option>Principiante</option><option>Intermedio</option><option>Avanzato</option></select></label>
        </div>
      </section>

      <section className="mb-5 rounded-3xl bg-white p-5 shadow-sm ring-1 ring-slate-200">
        <h2 className="mb-4 text-lg font-black">Obiettivo e contesto</h2>
        <div className="space-y-4">
          <label className={labelClass}>Obiettivo<select className={fieldClass} value={data.profile.goal} onChange={(e) => patch("goal", e.target.value as Goal)}>{goals.map((goal) => <option key={goal.value} value={goal.value}>{goal.label}</option>)}</select></label>
          <label className={labelClass}>Allenamenti a settimana<input className={fieldClass} type="range" min="3" max="6" value={data.profile.trainingDays} onChange={(e) => patch("trainingDays", Number(e.target.value))} /><span className="mt-2 block text-sm font-bold text-slate-900">{data.profile.trainingDays} giorni</span></label>
          <label className={labelClass}>Dove ti alleni<select className={fieldClass} value={data.profile.location} onChange={(e) => patch("location", e.target.value as TrainingLocation)}><option>Palestra</option><option>Casa</option><option>Misto</option></select></label>
          <label className={labelClass}>Attrezzatura disponibile<textarea className={`${fieldClass} min-h-20`} value={data.profile.equipment} onChange={(e) => patch("equipment", e.target.value)} placeholder="Es. sala pesi, manubri, macchine…" /></label>
          <label className={labelClass}>Alimentazione<select className={fieldClass} value={data.profile.diet} onChange={(e) => patch("diet", e.target.value as DietStyle)}><option>Onnivora</option><option>Vegetariana</option><option>Vegana</option><option>Pescetariana</option></select></label>
          <label className={labelClass}>Allergie / restrizioni / preferenze<textarea className={`${fieldClass} min-h-24`} value={data.profile.restrictions} onChange={(e) => patch("restrictions", e.target.value)} placeholder="Es. arachidi, lattosio, preferenze alimentari…" /></label>
        </div>
      </section>

      <section className="mb-5 rounded-3xl bg-gradient-to-br from-slate-900 to-slate-800 p-5 text-white shadow-xl">
        <div className="flex items-start gap-3"><Sparkles className="mt-0.5 text-blue-300" /><div className="flex-1"><h2 className="text-xl font-black">Genera il piano settimanale</h2><p className="mt-1 text-sm leading-6 text-slate-300">Una sola azione aggiorna workout, nutrizione e integratori. Le tue modifiche restano salvate sul dispositivo.</p></div></div>
        <button type="button" disabled={generating} onClick={generatePlan} className="mt-5 flex w-full items-center justify-center gap-2 rounded-2xl bg-blue-600 px-4 py-4 text-sm font-black transition hover:bg-blue-500 disabled:cursor-wait disabled:opacity-60">{generating ? "Generazione in corso…" : "Genera / rigenera piano"} <Sparkles size={17} /></button>
        {status && <p className="mt-3 rounded-xl bg-white/10 p-3 text-xs leading-5 text-slate-200">{status}</p>}
      </section>

      <section className="mb-5 rounded-3xl bg-white p-5 shadow-sm ring-1 ring-slate-200">
        <div className="flex items-center gap-3"><ShieldCheck className="text-emerald-600" /><div><h2 className="font-black">Privacy e backup</h2><p className="text-sm text-slate-500">I dati del profilo sono salvati localmente nel browser.</p></div></div>
        <div className="mt-4 grid gap-3 sm:grid-cols-3">
          <button type="button" onClick={exportData} className="flex items-center justify-center gap-2 rounded-xl bg-slate-100 px-3 py-3 text-sm font-bold"><Download size={16} /> Esporta</button>
          <label className="flex cursor-pointer items-center justify-center gap-2 rounded-xl bg-slate-100 px-3 py-3 text-sm font-bold"><Upload size={16} /> Importa<input className="hidden" type="file" accept="application/json,.json" onChange={importData} /></label>
          <button type="button" onClick={() => { if (confirm("Cancellare tutti i dati locali?")) reset(); }} className="flex items-center justify-center gap-2 rounded-xl bg-red-50 px-3 py-3 text-sm font-bold text-red-700"><FileJson size={16} /> Azzera dati</button>
        </div>
      </section>

      <p className="pb-4 text-center text-xs leading-5 text-slate-400">Il piano fitness è informativo e non sostituisce un medico, dietista o altro professionista sanitario.</p>
    </div>
  );
}
