"use client";

import { AlertTriangle, RefreshCw } from "lucide-react";

export default function Error({ reset }: { error: Error & { digest?: string }; reset: () => void }) {
  return (
    <main className="min-h-screen bg-slate-50 px-4 pb-24 pt-20 dark:bg-slate-950">
      <section className="mx-auto max-w-md rounded-3xl border border-slate-200 bg-white p-6 text-center shadow-sm dark:border-slate-800 dark:bg-slate-900">
        <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-300">
          <AlertTriangle size={28} />
        </div>
        <h1 className="mt-5 text-xl font-black text-slate-900 dark:text-white">Qualcosa è andato storto</h1>
        <p className="mt-2 text-sm leading-6 text-slate-500 dark:text-slate-400">
          La schermata ha avuto un problema temporaneo. I tuoi dati salvati sul dispositivo non vengono cancellati.
        </p>
        <button
          type="button"
          onClick={() => reset()}
          className="mt-6 inline-flex items-center gap-2 rounded-2xl bg-slate-950 px-5 py-3 text-sm font-bold text-white transition hover:bg-slate-800 dark:bg-white dark:text-slate-950"
        >
          <RefreshCw size={17} />
          Riprova
        </button>
      </section>
    </main>
  );
}
