# Fitness Pro

PWA Next.js per workout, nutrizione e integratori con piano settimanale personalizzato.

## Avvio

```bash
npm install
npm run dev
```

## AI su Vercel

La UI chiama `POST /api/generate-plan`. La route usa `OPENAI_API_KEY` lato server; se la chiave non è presente o il provider non risponde, l'app genera un piano locale di fallback e resta utilizzabile.

Configura su Vercel:

- `OPENAI_API_KEY` (Secret)
- `OPENAI_MODEL` (opzionale, default `gpt-5-mini`)

Non usare `NEXT_PUBLIC_OPENAI_API_KEY`.

## Funzioni incluse

- Profilo con obiettivo, frequenza, esperienza, attrezzatura e alimentazione
- Generazione di piano settimanale workout + nutrizione + integratori
- Tracking delle serie e delle sessioni
- Diario nutrizionale giornaliero
- Checklist integratori
- Backup/import JSON
- PWA installabile + service worker
- Fallback offline/local senza AI

## Note

I dati dell'utente sono salvati nel `localStorage` del browser. Questo progetto non include autenticazione o database remoto: per un'app multi-dispositivo serve aggiungere un backend/database e un sistema di autenticazione.
