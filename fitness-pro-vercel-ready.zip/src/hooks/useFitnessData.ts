"use client";

import { useCallback, useEffect, useState } from "react";
import { createDefaultData, loadData, persistData } from "@/lib/store";
import type { UserData } from "@/lib/types";

export function useFitnessData() {
  const [data, setData] = useState<UserData>(createDefaultData);
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    setData(loadData());
    setLoaded(true);

    const sync = () => setData(loadData());
    window.addEventListener("fitness:data-updated", sync);
    return () => window.removeEventListener("fitness:data-updated", sync);
  }, []);

  const save = useCallback((next: UserData | ((current: UserData) => UserData)) => {
    setData((current) => {
      const resolved = typeof next === "function" ? next(current) : next;
      persistData(resolved);
      return resolved;
    });
  }, []);

  const reset = useCallback(() => {
    const next = createDefaultData();
    persistData(next);
    setData(next);
  }, []);

  return { data, loaded, save, reset } as const;
}
