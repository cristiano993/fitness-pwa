import { calculateEstimatedMax, getNutritionTargets } from "./calculations";
import type { MealPlanItem, UserProfile, WeeklyPlan, Workout, SupplementPlanItem } from "./types";

const DAYS = ["Domenica", "Lunedì", "Martedì", "Mercoledì", "Giovedì", "Venerdì", "Sabato"];

const EXERCISES = {
  full: [
    ["Squat", "Gambe", 3, "6-10"],
    ["Panca piana", "Petto", 3, "6-10"],
    ["Lat machine", "Schiena", 3, "8-12"],
    ["Romanian deadlift", "Posteriori coscia", 3, "8-10"],
    ["Shoulder press", "Spalle", 2, "8-12"],
    ["Curl manubri", "Bicipiti", 2, "10-12"],
  ],
  upper: [
    ["Panca piana", "Petto", 3, "6-10"],
    ["Rematore", "Schiena", 3, "6-10"],
    ["Shoulder press", "Spalle", 3, "8-12"],
    ["Lat machine", "Schiena", 3, "8-12"],
    ["Pushdown tricipiti", "Tricipiti", 2, "10-15"],
    ["Curl manubri", "Bicipiti", 2, "10-15"],
  ],
  lower: [
    ["Squat", "Gambe", 3, "6-10"],
    ["Romanian deadlift", "Posteriori coscia", 3, "8-10"],
    ["Leg press", "Gambe", 3, "10-12"],
    ["Leg curl", "Posteriori coscia", 2, "10-15"],
    ["Calf raise", "Polpacci", 3, "10-15"],
    ["Plank", "Core", 3, "30-45 sec"],
  ],
  push: [
    ["Panca piana", "Petto", 3, "6-10"],
    ["Panca inclinata", "Petto", 3, "8-12"],
    ["Shoulder press", "Spalle", 3, "8-12"],
    ["Alzate laterali", "Spalle", 3, "12-15"],
    ["Pushdown tricipiti", "Tricipiti", 3, "10-15"],
  ],
  pull: [
    ["Lat machine", "Schiena", 3, "6-10"],
    ["Rematore", "Schiena", 3, "8-12"],
    ["Pulley basso", "Schiena", 3, "8-12"],
    ["Face pull", "Deltoidi posteriori", 2, "12-15"],
    ["Curl manubri", "Bicipiti", 3, "10-15"],
  ],
  legs: [
    ["Squat", "Quadricipiti", 3, "6-10"],
    ["Romanian deadlift", "Femorali", 3, "8-10"],
    ["Leg press", "Gambe", 3, "10-12"],
    ["Leg curl", "Femorali", 3, "10-15"],
    ["Calf raise", "Polpacci", 3, "10-15"],
  ],
} as const;

function id(prefix: string, index: number) {
  return `${prefix}-${index + 1}-${Date.now()}`;
}

function workoutFor(profile: UserProfile, dayOfWeek: number, index: number, type: keyof typeof EXERCISES): Workout {
  const definitions = EXERCISES[type];
  const exercises = definitions.map(([name, focus, sets, reps]: readonly [string, string, number, string], exerciseIndex: number) => ({
    id: id(`ex-${dayOfWeek}`, exerciseIndex),
    name,
    sets,
    reps,
    weight: 0,
    restSeconds: reps.startsWith("6") ? 150 : 90,
    rpe: profile.experience === "Principiante" ? 7 : 8,
    notes: `Focus: ${focus}. Mantieni una tecnica controllata e lascia almeno 1-3 ripetizioni in riserva.`,
  }));
  const focusNames: Record<typeof type, string> = {
    full: "Full body",
    upper: "Upper body",
    lower: "Lower body",
    push: "Push",
    pull: "Pull",
    legs: "Legs",
  };
  return {
    id: id("workout", index),
    name: `${DAYS[dayOfWeek]} · ${focusNames[type]}`,
    dayOfWeek,
    focus: focusNames[type],
    durationMinutes: 55 + Math.min(20, exercises.length * 2),
    exercises,
  };
}

function workoutTypes(days: number): (keyof typeof EXERCISES)[] {
  if (days <= 3) return ["full", "full", "full"];
  if (days === 4) return ["upper", "lower", "upper", "lower"];
  if (days === 5) return ["push", "pull", "legs", "upper", "lower"];
  return ["push", "pull", "legs", "push", "pull", "legs"];
}

function buildMeals(profile: UserProfile, nutrition: ReturnType<typeof getNutritionTargets>): Record<string, MealPlanItem[]> {
  const split = [0.25, 0.35, 0.15, 0.25];
  const names = ["Colazione", "Pranzo", "Spuntino", "Cena"];
  const templates = [
    "Yogurt greco, avena e frutta",
    profile.diet === "Vegana"
      ? "Bowl di riso, tofu e verdure"
      : profile.diet === "Vegetariana"
        ? "Riso, legumi e verdure"
        : profile.diet === "Pescetariana"
          ? "Riso, salmone e verdure"
          : "Riso, pollo e verdure",
    "Frutta e una fonte proteica",
    profile.diet === "Vegetariana" ? "Uova, patate e verdure" : profile.diet === "Vegana" ? "Legumi, patate e verdure" : "Pesce, patate e verdure",
  ];
  const result: Record<string, MealPlanItem[]> = {};
  for (let day = 0; day < 7; day += 1) {
    const key = String(day);
    result[key] = names.map((meal, index) => {
      const calories = Math.round(nutrition.calories * split[index]);
      const protein = Math.round(nutrition.protein * [0.25, 0.35, 0.15, 0.25][index]);
      const carbs = Math.round(nutrition.carbs * split[index]);
      const fat = Math.max(1, Math.round(nutrition.fat * split[index]));
      return {
        id: `meal-${day}-${index}`,
        meal,
        name: templates[index],
        calories,
        protein,
        carbs,
        fat,
        items: [templates[index]],
        consumed: false,
      };
    });
  }
  return result;
}

function buildSupplements(): SupplementPlanItem[] {
  return [
    {
      id: "supp-creatine",
      name: "Creatina monoidrato",
      dosage: "3–5 g",
      timing: "Ogni giorno, quando è più comodo",
      notes: "Opzione basata sull'evidenza per supportare performance e forza. Verifica idoneità personale e segui il parere di un professionista.",
      completed: false,
    },
    {
      id: "supp-protein",
      name: "Proteine in polvere",
      dosage: "Solo quanto serve a coprire il fabbisogno",
      timing: "Quando comodo",
      notes: "Alimento pratico, non obbligatorio. Usalo come supporto alla dieta, non come sostituto dei pasti.",
      completed: false,
    },
  ];
}

export function buildFallbackPlan(profile: UserProfile): WeeklyPlan {
  const nutrition = getNutritionTargets(profile);
  const types = workoutTypes(profile.trainingDays);
  const chosenDays = [1, 2, 3, 4, 5, 6].slice(0, profile.trainingDays);
  const workouts = chosenDays.map((day, index) => workoutFor(profile, day, index, types[index]));

  return {
    id: `plan-${Date.now()}`,
    generatedAt: new Date().toISOString(),
    source: "fallback",
    title: `Piano ${profile.goal}`,
    summary: `Settimana personalizzata per ${profile.name || "te"}: ${profile.trainingDays} allenamenti, obiettivo ${profile.goal.toLowerCase()} e target nutrizionali calcolati dai dati inseriti.`,
    nutrition: {
      calories: nutrition.calories,
      protein: nutrition.protein,
      carbs: nutrition.carbs,
      fat: nutrition.fat,
    },
    meals: buildMeals(profile, nutrition),
    workouts,
    supplements: buildSupplements(),
    notes: [
      "Il piano è un punto di partenza: adatta carichi e volume alla tua esperienza.",
      "Per allergie, patologie, gravidanza, farmaci o esigenze cliniche serve il parere di un professionista sanitario.",
      `1RM stimato e progressioni vanno interpretati come stime: non usarli come test massimali.`,
    ],
  };
}

export function sanitizeAiPlan(input: unknown, profile: UserProfile): WeeklyPlan {
  const fallback = buildFallbackPlan(profile);
  if (!input || typeof input !== "object") return fallback;
  const raw = input as Record<string, unknown>;
  const nutritionRaw = (raw.nutrition as Record<string, unknown> | undefined) ?? {};
  const rawWorkouts = Array.isArray(raw.workouts) ? raw.workouts : [];
  const rawMealDays = Array.isArray(raw.mealDays) ? raw.mealDays : [];
  const rawMeals = raw.meals && typeof raw.meals === "object" ? (raw.meals as Record<string, unknown>) : {};
  const rawSupplements = Array.isArray(raw.supplements) ? raw.supplements : [];
  const number = (value: unknown, fallbackValue: number) => (typeof value === "number" && Number.isFinite(value) ? value : fallbackValue);
  const text = (value: unknown, fallbackValue: string) => (typeof value === "string" && value.trim() ? value.trim() : fallbackValue);
  const workouts = rawWorkouts.slice(0, 6).map((item, workoutIndex) => {
    const workout = item as Record<string, unknown>;
    const rawExercises = Array.isArray(workout.exercises) ? workout.exercises : [];
    return {
      id: text(workout.id, `ai-workout-${workoutIndex}`),
      name: text(workout.name, `Allenamento ${workoutIndex + 1}`),
      dayOfWeek: Math.min(6, Math.max(0, Math.round(number(workout.dayOfWeek, workoutIndex + 1)))),
      focus: text(workout.focus, "Full body"),
      durationMinutes: Math.round(number(workout.durationMinutes, 60)),
      exercises: rawExercises.slice(0, 12).map((entry, exerciseIndex) => {
        const exercise = entry as Record<string, unknown>;
        const estimated = number(exercise.weight, 0);
        const repsValue = text(exercise.reps, "8-12");
        const firstReps = Number.parseInt(repsValue, 10) || 10;
        return {
          id: text(exercise.id, `ai-ex-${workoutIndex}-${exerciseIndex}`),
          name: text(exercise.name, "Esercizio"),
          sets: Math.min(8, Math.max(1, Math.round(number(exercise.sets, 3)))),
          reps: repsValue,
          weight: estimated,
          restSeconds: Math.min(360, Math.max(30, Math.round(number(exercise.restSeconds, 120)))),
          rpe: Math.min(10, Math.max(5, Math.round(number(exercise.rpe, 8)))),
          notes: text(exercise.notes, "Mantieni tecnica controllata e un margine di ripetizioni.")
            + (estimated > 0 ? ` 1RM stimato: ${calculateEstimatedMax(estimated, firstReps)} kg.` : ""),
        };
      }),
    } satisfies Workout;
  }).filter((workout) => workout.exercises.length > 0);

  const meals: Record<string, MealPlanItem[]> = {};
  for (let day = 0; day < 7; day += 1) {
    const mealDay = rawMealDays.find((entry) => {
      if (!entry || typeof entry !== "object") return false;
      const record = entry as Record<string, unknown>;
      return Number(record.dayOfWeek) === day;
    }) as Record<string, unknown> | undefined;
    const entries = mealDay && Array.isArray(mealDay.meals)
      ? (mealDay.meals as unknown[])
      : Array.isArray(rawMeals[String(day)])
        ? (rawMeals[String(day)] as unknown[])
        : [];
    meals[String(day)] = entries.slice(0, 6).map((entry, mealIndex) => {
      const meal = entry as Record<string, unknown>;
      return {
        id: text(meal.id, `ai-meal-${day}-${mealIndex}`),
        meal: text(meal.meal, "Pasto"),
        name: text(meal.name, "Pasto personalizzato"),
        calories: Math.max(0, Math.round(number(meal.calories, 0))),
        protein: Math.max(0, Math.round(number(meal.protein, 0))),
        carbs: Math.max(0, Math.round(number(meal.carbs, 0))),
        fat: Math.max(0, Math.round(number(meal.fat, 0))),
        items: Array.isArray(meal.items) ? meal.items.filter((x): x is string => typeof x === "string").slice(0, 8) : [text(meal.name, "Pasto personalizzato")],
        consumed: false,
      };
    });
  }

  const supplements = rawSupplements.slice(0, 8).map((entry, index) => {
    const supplement = entry as Record<string, unknown>;
    return {
      id: text(supplement.id, `ai-supp-${index}`),
      name: text(supplement.name, "Integratore"),
      dosage: text(supplement.dosage, "Segui etichetta"),
      timing: text(supplement.timing, "Quando indicato"),
      notes: text(supplement.notes, "Valuta l'idoneità con un professionista."),
      completed: false,
    };
  });

  return {
    id: text(raw.id, fallback.id),
    generatedAt: new Date().toISOString(),
    source: "ai",
    title: text(raw.title, fallback.title),
    summary: text(raw.summary, fallback.summary),
    nutrition: {
      calories: Math.max(1200, Math.round(number(nutritionRaw.calories, fallback.nutrition.calories))),
      protein: Math.max(40, Math.round(number(nutritionRaw.protein, fallback.nutrition.protein))),
      carbs: Math.max(50, Math.round(number(nutritionRaw.carbs, fallback.nutrition.carbs))),
      fat: Math.max(30, Math.round(number(nutritionRaw.fat, fallback.nutrition.fat))),
    },
    meals: Object.values(meals).some((items) => items.length > 0) ? meals : fallback.meals,
    workouts: workouts.length ? workouts : fallback.workouts,
    supplements: supplements.length ? supplements : fallback.supplements,
    notes: Array.isArray(raw.notes) ? raw.notes.filter((x): x is string => typeof x === "string").slice(0, 6) : fallback.notes,
  };
}
