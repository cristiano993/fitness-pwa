import type { Goal, Sex, UserProfile } from "./types";

export function calculateEstimatedMax(weight: number, reps: number): number {
  if (!Number.isFinite(weight) || !Number.isFinite(reps) || weight <= 0 || reps <= 0) return 0;
  if (reps === 1) return Math.round(weight);
  return Math.round(weight * (1 + reps / 30));
}

export function calculateBMR(age: number, height: number, weight: number, sex: Sex): number {
  const base = 10 * weight + 6.25 * height - 5 * age;
  return Math.round(sex === "M" ? base + 5 : base - 161);
}

export function calculateTDEE(profile: Pick<UserProfile, "age" | "height" | "weight" | "sex" | "trainingDays">): number {
  const bmr = calculateBMR(profile.age, profile.height, profile.weight, profile.sex);
  const activity = profile.trainingDays >= 6 ? 1.65 : profile.trainingDays === 5 ? 1.55 : profile.trainingDays === 4 ? 1.5 : profile.trainingDays === 3 ? 1.425 : 1.35;
  return Math.round(bmr * activity);
}

export function getNutritionTargets(profile: Pick<UserProfile, "age" | "height" | "weight" | "sex" | "trainingDays" | "goal">) {
  const tdee = calculateTDEE(profile);
  const calorieAdjustment: Record<Goal, number> = {
    Ipertrofia: 220,
    Forza: 120,
    Definizione: -380,
    Mantenimento: 0,
  };
  const calories = Math.max(1400, tdee + calorieAdjustment[profile.goal]);
  const proteinPerKg: Record<Goal, number> = {
    Ipertrofia: 1.8,
    Forza: 1.8,
    Definizione: 2.0,
    Mantenimento: 1.6,
  };
  const protein = Math.round(profile.weight * proteinPerKg[profile.goal]);
  const fat = Math.max(45, Math.round(profile.weight * 0.8));
  const carbs = Math.max(80, Math.round((calories - protein * 4 - fat * 9) / 4));

  return { calories, protein, carbs, fat, tdee };
}

export function getDailyTips(goal: Goal): string[] {
  const tips: Record<Goal, string[]> = {
    Ipertrofia: [
      "Mantieni una progressione graduale dei carichi o delle ripetizioni.",
      "Distribuisci le proteine su più pasti durante la giornata.",
      "Dai priorità a sonno, recupero e tecnica prima di aumentare il volume.",
    ],
    Forza: [
      "Usa recuperi più lunghi sugli esercizi principali e mantieni una tecnica stabile.",
      "Registra carico, ripetizioni e percezione dello sforzo per seguire i progressi.",
      "Evita di trasformare ogni serie in un test massimale.",
    ],
    Definizione: [
      "Mantieni allenamento di forza e un apporto proteico adeguato mentre controlli l'energia totale.",
      "Valuta il trend del peso su più settimane, non il singolo giorno.",
      "Costanza e recupero sono più importanti di tagli calorici estremi.",
    ],
    Mantenimento: [
      "Concentrati su performance, recupero e regolarità.",
      "Usa il diario per individuare abitudini che funzionano davvero per te.",
      "Mantieni una routine sostenibile anche nelle settimane più impegnative.",
    ],
  };
  return tips[goal];
}
