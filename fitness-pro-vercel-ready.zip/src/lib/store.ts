import { getNutritionTargets } from "./calculations";
import type { Goal, UserData, UserProfile, Workout, MealPlanItem, SupplementPlanItem, WorkoutSession } from "./types";

export const STORAGE_KEY = "fitness-pwa:data:v2";

const LEGACY_GOAL_MAP: Record<string, Goal> = {
  Hypertrophy: "Ipertrofia",
  Strength: "Forza",
  Definition: "Definizione",
  Maintenance: "Mantenimento",
};

const GOALS: Goal[] = ["Ipertrofia", "Forza", "Definizione", "Mantenimento"];
const EXPERIENCES: UserProfile["experience"][] = ["Principiante", "Intermedio", "Avanzato"];
const LOCATIONS: UserProfile["location"][] = ["Palestra", "Casa", "Misto"];
const DIETS: UserProfile["diet"][] = ["Onnivora", "Vegetariana", "Vegana", "Pescetariana"];

export const localDateKey = (date = new Date()) => {
  const offset = date.getTimezoneOffset() * 60_000;
  return new Date(date.getTime() - offset).toISOString().slice(0, 10);
};

export function createDefaultProfile(): UserProfile {
  return {
    id: cryptoSafeId(),
    name: "",
    age: 30,
    height: 175,
    weight: 70,
    sex: "M",
    goal: "Ipertrofia",
    trainingDays: 4,
    experience: "Principiante",
    location: "Palestra",
    equipment: "Sala pesi completa",
    diet: "Onnivora",
    restrictions: "",
    createdAt: new Date().toISOString(),
  };
}

export function createDefaultData(): UserData {
  return {
    version: 3,
    profile: createDefaultProfile(),
    weightHistory: [],
    plan: null,
    workoutLogs: [],
    dailyNutrition: {},
    dailyMealStatus: {},
    customMeals: [],
    supplements: [],
  };
}

function cryptoSafeId(): string {
  if (typeof crypto !== "undefined" && "randomUUID" in crypto) {
    return crypto.randomUUID();
  }
  return `id-${Date.now()}-${Math.random().toString(36).slice(2, 10)}`;
}

function asNumber(value: unknown, fallback: number): number {
  return typeof value === "number" && Number.isFinite(value) ? value : fallback;
}

function clamp(value: number, min: number, max: number): number {
  return Math.min(max, Math.max(min, value));
}

function asString(value: unknown, fallback = ""): string {
  return typeof value === "string" ? value : fallback;
}

function normalizeProfile(rawValue: unknown, base: UserProfile): UserProfile {
  const raw = rawValue && typeof rawValue === "object" ? rawValue as Record<string, unknown> : {};
  const rawGoal = String(raw.goal ?? "");
  const goal = LEGACY_GOAL_MAP[rawGoal] ?? (GOALS.includes(raw.goal as Goal) ? raw.goal as Goal : base.goal);
  const rawExperience = raw.experience as UserProfile["experience"];
  const rawLocation = raw.location as UserProfile["location"];
  const rawDiet = raw.diet as UserProfile["diet"];
  const rawSex = raw.sex ?? raw.gender;

  return {
    ...base,
    id: asString(raw.id, base.id),
    name: asString(raw.name).slice(0, 100),
    age: Math.round(clamp(asNumber(raw.age, base.age), 14, 100)),
    height: Math.round(clamp(asNumber(raw.height, base.height), 120, 230)),
    weight: Math.round(clamp(asNumber(raw.weight, base.weight), 35, 300) * 10) / 10,
    sex: rawSex === "F" ? "F" : "M",
    goal,
    trainingDays: Math.round(clamp(asNumber(raw.trainingDays, base.trainingDays), 3, 6)),
    experience: EXPERIENCES.includes(rawExperience) ? rawExperience : base.experience,
    location: LOCATIONS.includes(rawLocation) ? rawLocation : base.location,
    equipment: asString(raw.equipment, base.equipment).slice(0, 1500),
    diet: DIETS.includes(rawDiet) ? rawDiet : base.diet,
    restrictions: asString(raw.restrictions).slice(0, 3000),
    createdAt: asString(raw.createdAt, base.createdAt),
  };
}

function normalizeWeightHistory(value: unknown, profile: UserProfile): UserData["weightHistory"] {
  if (!Array.isArray(value)) return [{ date: localDateKey(), weight: profile.weight }];
  const history = value
    .filter((item): item is Record<string, unknown> => Boolean(item && typeof item === "object"))
    .map((item) => ({
      date: asString(item.date),
      weight: asNumber(item.weight, 0),
    }))
    .filter((item) => /^\d{4}-\d{2}-\d{2}$/.test(item.date) && item.weight > 0);
  return history.length ? history : [{ date: localDateKey(), weight: profile.weight }];
}

function normalizeSupplements(value: unknown): SupplementPlanItem[] {
  if (!Array.isArray(value)) return [];
  return value
    .filter((item): item is Record<string, unknown> => Boolean(item && typeof item === "object"))
    .map((item) => ({
      id: asString(item.id, cryptoSafeId()),
      name: asString(item.name, "Integratore").slice(0, 100),
      dosage: asString(item.dosage ?? item.dose, "Segui etichetta").slice(0, 100),
      timing: asString(item.timing ?? item.time, "Quando indicato").slice(0, 150),
      notes: asString(item.notes, "Verifica sempre etichetta, tolleranza e compatibilità con le tue esigenze.").slice(0, 1000),
      completed: Boolean(item.completed),
      completedDate: typeof item.completedDate === "string"
        ? item.completedDate
        : item.completed
          ? localDateKey()
          : undefined,
    }));
}

function normalizeCustomMeals(value: unknown): MealPlanItem[] {
  if (!Array.isArray(value)) return [];
  return value
    .filter((item): item is Record<string, unknown> => Boolean(item && typeof item === "object"))
    .map((item) => ({
      id: asString(item.id, cryptoSafeId()),
      date: asString(item.date, localDateKey()),
      meal: asString(item.meal, "Personalizzato"),
      name: asString(item.name, "Pasto personalizzato").slice(0, 150),
      calories: Math.max(0, Math.round(asNumber(item.calories, 0))),
      protein: Math.max(0, Math.round(asNumber(item.protein, 0))),
      carbs: Math.max(0, Math.round(asNumber(item.carbs, 0))),
      fat: Math.max(0, Math.round(asNumber(item.fat, 0))),
      items: Array.isArray(item.items) ? item.items.filter((x): x is string => typeof x === "string").slice(0, 8) : [],
      consumed: Boolean(item.consumed),
    }));
}

function normalizeDailyNutrition(value: unknown): UserData["dailyNutrition"] {
  if (!value || typeof value !== "object") return {};
  const result: UserData["dailyNutrition"] = {};
  for (const [date, raw] of Object.entries(value)) {
    if (!raw || typeof raw !== "object") continue;
    const entry = raw as Record<string, unknown>;
    result[date] = {
      calories: Math.max(0, Math.round(asNumber(entry.calories, 0))),
      protein: Math.max(0, Math.round(asNumber(entry.protein, 0))),
      carbs: Math.max(0, Math.round(asNumber(entry.carbs, 0))),
      fat: Math.max(0, Math.round(asNumber(entry.fat, 0))),
    };
  }
  return result;
}

function normalizeDailyMealStatus(value: unknown): UserData["dailyMealStatus"] {
  if (!value || typeof value !== "object") return {};
  const result: UserData["dailyMealStatus"] = {};
  for (const [date, raw] of Object.entries(value)) {
    if (!raw || typeof raw !== "object") continue;
    result[date] = {};
    for (const [mealId, status] of Object.entries(raw as Record<string, unknown>)) {
      if (typeof status === "boolean") result[date][mealId] = status;
    }
  }
  return result;
}

function normalizeWorkoutLogs(value: unknown): WorkoutSession[] {
  if (!Array.isArray(value)) return [];
  return value.filter((item): item is WorkoutSession => Boolean(
    item &&
    typeof item === "object" &&
    typeof (item as WorkoutSession).id === "string" &&
    typeof (item as WorkoutSession).workoutId === "string" &&
    typeof (item as WorkoutSession).date === "string",
  ));
}

function normalizePlan(value: unknown): UserData["plan"] {
  if (!value || typeof value !== "object") return null;
  const plan = value as UserData["plan"];
  if (!plan || typeof plan.id !== "string" || !plan.nutrition || !Array.isArray(plan.workouts)) return null;
  return plan;
}

function migrateLegacy(input: Record<string, unknown>, profile: UserProfile, base: UserData): UserData {
  const oldSupplements = Array.isArray(input.supplements) ? input.supplements : [];
  const oldRoutines = Array.isArray(input.routines) ? input.routines : [];
  const migratedSupplements = normalizeSupplements(oldSupplements);

  const routines = oldRoutines
    .filter((routine): routine is Record<string, unknown> => Boolean(routine && typeof routine === "object"))
    .map((routine, index) => ({
      id: asString(routine.id, cryptoSafeId()),
      name: asString(routine.name, `Workout ${index + 1}`),
      dayOfWeek: index,
      focus: "Full body",
      durationMinutes: 60,
      exercises: Array.isArray(routine.exercises)
        ? routine.exercises
            .filter((exercise): exercise is Record<string, unknown> => Boolean(exercise && typeof exercise === "object"))
            .map((exercise) => ({
              id: asString(exercise.id, cryptoSafeId()),
              name: asString(exercise.name, "Esercizio"),
              sets: 3,
              reps: "8-12",
              weight: asNumber((exercise.lastSet as Record<string, unknown> | undefined)?.weight, 0),
              restSeconds: 120,
            }))
        : [],
    }));

  const legacyNutrition = input.nutrition && typeof input.nutrition === "object"
    ? input.nutrition as Record<string, unknown>
    : null;
  const calculatedNutrition = getNutritionTargets(profile);
  const legacyPlan: UserData["plan"] = routines.length
    ? {
        id: `migrated-plan-${Date.now()}`,
        generatedAt: new Date().toISOString(),
        source: "fallback",
        title: "Piano migrato dal vecchio progetto",
        summary: "Questo piano proviene dai dati della versione precedente dell'app. Puoi rigenerarlo dal profilo.",
        nutrition: {
          calories: asNumber(legacyNutrition?.calories, calculatedNutrition.calories),
          protein: asNumber(legacyNutrition?.protein, calculatedNutrition.protein),
          carbs: asNumber(legacyNutrition?.carbs, calculatedNutrition.carbs),
          fat: asNumber(legacyNutrition?.fat, calculatedNutrition.fat),
        },
        meals: {},
        workouts: routines as Workout[],
        supplements: migratedSupplements,
        notes: ["Piano migrato automaticamente dalla versione precedente.", "Rigenerando il piano dal profilo otterrai la nuova struttura completa."],
      }
    : null;

  return {
    ...base,
    profile,
    plan: legacyPlan,
    supplements: migratedSupplements,
    weightHistory: normalizeWeightHistory(input.weightHistory, profile),
    workoutLogs: normalizeWorkoutLogs(input.workoutLogs),
  };
}

function migrate(input: unknown): UserData {
  const base = createDefaultData();
  if (!input || typeof input !== "object") return base;
  const raw = input as Record<string, unknown>;
  const profile = normalizeProfile(raw.profile, base.profile);

  const looksLikeCurrentData = raw.version === 2 || raw.version === 3 || raw.plan !== undefined || raw.dailyNutrition !== undefined || raw.customMeals !== undefined || raw.dailyMealStatus !== undefined;
  if (!looksLikeCurrentData) return migrateLegacy(raw, profile, base);

  const plan = normalizePlan(raw.plan);
  const dailyMealStatus = normalizeDailyMealStatus(raw.dailyMealStatus);
  const currentDate = localDateKey();
  if (!dailyMealStatus[currentDate] && plan?.meals) {
    const consumedToday: Record<string, boolean> = {};
    const dayMeals = plan.meals[String(new Date().getDay())] ?? [];
    for (const meal of dayMeals) {
      if (meal.consumed) consumedToday[meal.id] = true;
    }
    if (Object.keys(consumedToday).length) dailyMealStatus[currentDate] = consumedToday;
  }

  return {
    ...base,
    version: 3,
    profile,
    plan,
    supplements: normalizeSupplements(raw.supplements ?? plan?.supplements),
    weightHistory: normalizeWeightHistory(raw.weightHistory, profile),
    workoutLogs: normalizeWorkoutLogs(raw.workoutLogs),
    dailyNutrition: normalizeDailyNutrition(raw.dailyNutrition),
    dailyMealStatus,
    customMeals: normalizeCustomMeals(raw.customMeals),
  };
}

export function loadData(): UserData {
  if (typeof window === "undefined") return createDefaultData();
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) return createDefaultData();
    return migrate(JSON.parse(raw));
  } catch (error) {
    console.error("Impossibile caricare i dati fitness:", error);
    return createDefaultData();
  }
}

export function persistData(data: UserData): void {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify({ ...data, version: 3 }));
    window.dispatchEvent(new CustomEvent("fitness:data-updated"));
  } catch (error) {
    console.error("Impossibile salvare i dati fitness:", error);
  }
}

export function updateProfile(data: UserData, patch: Partial<UserProfile>): UserData {
  return {
    ...data,
    profile: { ...data.profile, ...patch },
  };
}
