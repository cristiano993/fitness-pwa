export type Goal = "Ipertrofia" | "Forza" | "Definizione" | "Mantenimento";
export type Sex = "M" | "F";
export type Experience = "Principiante" | "Intermedio" | "Avanzato";
export type TrainingLocation = "Palestra" | "Casa" | "Misto";
export type DietStyle = "Onnivora" | "Vegetariana" | "Vegana" | "Pescetariana";

export interface UserProfile {
  id: string;
  name: string;
  age: number;
  height: number;
  weight: number;
  sex: Sex;
  goal: Goal;
  trainingDays: number;
  experience: Experience;
  location: TrainingLocation;
  equipment: string;
  diet: DietStyle;
  restrictions: string;
  createdAt: string;
}

export interface WeightHistory {
  date: string;
  weight: number;
}

export interface Exercise {
  id: string;
  name: string;
  sets: number;
  reps: string;
  weight: number;
  restSeconds: number;
  rpe?: number;
  notes?: string;
  lastSessionWeight?: number;
  lastSessionReps?: number;
  estimatedMax?: number;
}

export interface Workout {
  id: string;
  name: string;
  dayOfWeek: number;
  focus: string;
  durationMinutes: number;
  exercises: Exercise[];
  completed?: boolean;
}

export interface WorkoutSet {
  weight: number;
  reps: number;
  completed: boolean;
}

export interface WorkoutSession {
  id: string;
  workoutId: string;
  date: string;
  duration: number;
  totalVolume: number;
  exercises: {
    exerciseId: string;
    completedSets: WorkoutSet[];
  }[];
}

export interface SupplementPlanItem {
  id: string;
  name: string;
  dosage: string;
  timing: string;
  notes: string;
  completed: boolean;
  completedDate?: string;
}

export interface NutritionTarget {
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
}

export interface MealPlanItem {
  id: string;
  date?: string;
  meal: string;
  name: string;
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
  items: string[];
  consumed: boolean;
}

export interface DailyNutritionLog {
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
}

export interface WeeklyPlan {
  id: string;
  generatedAt: string;
  source: "ai" | "fallback";
  title: string;
  summary: string;
  nutrition: NutritionTarget;
  meals: Record<string, MealPlanItem[]>;
  workouts: Workout[];
  supplements: SupplementPlanItem[];
  notes: string[];
}

export interface UserData {
  version: 3;
  profile: UserProfile;
  weightHistory: WeightHistory[];
  plan: WeeklyPlan | null;
  workoutLogs: WorkoutSession[];
  dailyNutrition: Record<string, DailyNutritionLog>;
  dailyMealStatus: Record<string, Record<string, boolean>>;
  customMeals: MealPlanItem[];
  supplements: SupplementPlanItem[];
}

export const GOAL_LABELS: Record<Goal, string> = {
  Ipertrofia: "Aumentare massa muscolare",
  Forza: "Aumentare forza",
  Definizione: "Ridurre grasso e preservare massa",
  Mantenimento: "Mantenere forma e performance",
};
