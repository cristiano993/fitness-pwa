"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { Apple, Dumbbell, House, Pill, User } from "lucide-react";

const ITEMS = [
  { href: "/", label: "Home", icon: House },
  { href: "/workout", label: "Workout", icon: Dumbbell },
  { href: "/nutrition", label: "Cibo", icon: Apple },
  { href: "/supplements", label: "Integratori", icon: Pill },
  { href: "/profile", label: "Profilo", icon: User },
];

export default function BottomNav() {
  const pathname = usePathname();
  return (
    <nav className="fixed inset-x-0 bottom-0 z-40 border-t border-slate-200 bg-white/95 pb-[env(safe-area-inset-bottom)] shadow-[0_-8px_30px_rgba(15,23,42,0.08)] backdrop-blur">
      <div className="mx-auto flex max-w-3xl">
        {ITEMS.map(({ href, label, icon: Icon }) => {
          const active = href === "/" ? pathname === "/" : pathname.startsWith(href);
          return (
            <Link key={href} href={href} className={`flex min-h-16 flex-1 flex-col items-center justify-center gap-1 text-[11px] font-semibold transition ${active ? "text-blue-600" : "text-slate-500"}`}>
              <span className={`grid h-8 w-10 place-items-center rounded-full ${active ? "bg-blue-50" : ""}`}>
                <Icon size={20} strokeWidth={active ? 2.5 : 2} />
              </span>
              <span>{label}</span>
            </Link>
          );
        })}
      </div>
    </nav>
  );
}
