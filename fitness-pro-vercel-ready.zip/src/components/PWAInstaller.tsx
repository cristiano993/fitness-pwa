"use client";

import { useEffect, useState } from "react";
import { Download, X } from "lucide-react";

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: "accepted" | "dismissed" }>;
}

export default function PWAInstaller() {
  const [deferredPrompt, setDeferredPrompt] = useState<BeforeInstallPromptEvent | null>(null);
  const [show, setShow] = useState(false);

  useEffect(() => {
    if (window.matchMedia("(display-mode: standalone)").matches) return;
    const handler = (event: Event) => {
      event.preventDefault();
      setDeferredPrompt(event as BeforeInstallPromptEvent);
      setShow(true);
    };
    window.addEventListener("beforeinstallprompt", handler);
    return () => window.removeEventListener("beforeinstallprompt", handler);
  }, []);

  const install = async () => {
    if (!deferredPrompt) return;
    await deferredPrompt.prompt();
    await deferredPrompt.userChoice;
    setDeferredPrompt(null);
    setShow(false);
  };

  if (!show) return null;

  return (
    <div className="fixed inset-x-3 top-3 z-50 mx-auto max-w-xl rounded-2xl border border-slate-200 bg-white p-3 shadow-2xl safe-top">
      <div className="flex items-center gap-3">
        <div className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-blue-600 text-white">
          <Download size={20} />
        </div>
        <div className="min-w-0 flex-1">
          <p className="font-semibold text-slate-900">Installa Fitness Pro</p>
          <p className="text-xs text-slate-500">Accesso rapido dalla schermata Home.</p>
        </div>
        <button type="button" aria-label="Chiudi" onClick={() => setShow(false)} className="rounded-full p-2 text-slate-400 hover:bg-slate-100">
          <X size={18} />
        </button>
        <button type="button" onClick={install} className="rounded-xl bg-slate-900 px-3 py-2 text-xs font-bold text-white">
          Installa
        </button>
      </div>
    </div>
  );
}
